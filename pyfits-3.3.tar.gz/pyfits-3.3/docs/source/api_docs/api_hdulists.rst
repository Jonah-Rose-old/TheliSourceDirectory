.. currentmodule:: pyfits

*********
HDU Lists
*********

.. inheritance-diagram:: HDUList

:class:`HDUList`
================

.. autoclass:: HDUList
   :members:
   :undoc-members:
   :show-inheritance:
