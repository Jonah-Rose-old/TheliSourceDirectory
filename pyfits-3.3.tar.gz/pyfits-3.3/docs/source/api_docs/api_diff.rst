*******
Differs
*******

.. automodule:: pyfits.diff
.. currentmodule:: pyfits

:class:`FITSDiff`
=================
.. autoclass:: FITSDiff
   :members:
   :inherited-members:
   :show-inheritance:

:class:`HDUDiff`
================
.. autoclass:: HDUDiff
   :members:
   :inherited-members:
   :show-inheritance:

:class:`HeaderDiff`
===================
.. autoclass:: HeaderDiff
   :members:
   :inherited-members:
   :show-inheritance:

:class:`ImageDataDiff`
======================
.. autoclass:: ImageDataDiff
   :members:
   :inherited-members:
   :show-inheritance:

:class:`RawDataDiff`
====================
.. autoclass:: RawDataDiff
   :members:
   :inherited-members:
   :show-inheritance:

:class:`TableDataDiff`
======================
.. autoclass:: TableDataDiff
   :members:
   :inherited-members:
   :show-inheritance:
